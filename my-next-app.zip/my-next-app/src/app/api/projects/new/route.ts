// src/app/api/projects/new/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { v4 as uuidv4 } from 'uuid';
import { INITIAL_DATA, ProjectFormData } from '@/features/projects/schema';
import getDb from '@/lib/db/project-draft';

export async function POST(req: NextRequest) {
  const { createdBy } = await req.json();

  if (!createdBy) {
    return NextResponse.json({ error: 'Missing creator info' }, { status: 400 });
  }

  const db = await getDb();

  const projectId = uuidv4();
  const now = new Date().toISOString();

  const newProject: ProjectFormData = {
    ...INITIAL_DATA,
    projectId,
    createdBy,
    createdAt: now,
    updatedBy: createdBy,
    updatedAt: now,
    status: 'draft',
    isArchived: false,
  };

  db.data!.push(newProject);
  await db.write();

  return NextResponse.json({ projectId });
}
