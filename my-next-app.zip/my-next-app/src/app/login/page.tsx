'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema, LoginSchemaType } from '@/features/login/schema';
import { getSession, signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/shared/store';
import { login } from '@/shared/store/slices/authSlice';

export default function LoginPage() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginSchemaType>({
    resolver: zodResolver(loginSchema),
  });

  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleCredentialsLogin = async (data: LoginSchemaType) => {
    setIsLoading(true);
    setErrorMessage(null);

    const result = await signIn('credentials', {
      ...data,
      redirect: false,
    });

    setIsLoading(false);

    if (result?.ok) {
      const session = await getSession();

      if (session?.user) {
        dispatch(
          login({
            user: session.user,
            token: session, // you can also access session.accessToken if you're storing that
          })
        );
      }

      router.push('/');
    } else {
      if (result?.error && result?.error === 'CredentialsSignIn') {
        setErrorMessage('Invalid email or password');
      }
      if (result?.error && result?.error === 'OAuthAccountNotLinked') {
        setErrorMessage('You have tried to login with wrong provider');
      }
      if (result?.error && result?.error === 'Configuration') {
        setErrorMessage('Provider misconfigured');
      }

      setErrorMessage(result?.error || 'Login failed');
    }
  };

  const handleProviderLogin = async (provider: 'google' | 'github') => {
    console.log('provider', provider);
    setIsLoading(true);
    await signIn(provider, { callbackUrl: '/' });
  };

  return (
    <div className="max-w-md mx-auto py-10 px-4 text-gray-900 dark:text-gray-100">
      <h1 className="text-2xl font-bold mb-6">Sign In</h1>

      <form
        onSubmit={handleSubmit(handleCredentialsLogin)}
        className="space-y-4"
      >
        <input
          type="email"
          {...register('email')}
          placeholder="Email"
          className="w-full px-4 py-2 border rounded"
        />
        {errors.email && (
          <p className="text-sm text-red-600">{errors.email.message}</p>
        )}

        <input
          type="password"
          {...register('password')}
          placeholder="Password"
          className="w-full px-4 py-2 border rounded"
        />
        {errors.password && (
          <p className="text-sm text-red-600">{errors.password.message}</p>
        )}

        {errorMessage && <p className="text-sm text-red-600">{errorMessage}</p>}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded disabled:opacity-50"
        >
          {isLoading ? 'Signing in…' : 'Sign In'}
        </button>
      </form>

      <div className="my-6 text-center text-gray-500">or</div>

      <button
        onClick={() => handleProviderLogin('google')}
        className="w-full bg-white border border-gray-300 hover:bg-gray-100 text-black py-2 rounded flex items-center justify-center gap-2 mb-2"
      >
        <img src="/icons/google.svg" alt="Google" className="w-5 h-5" />
        Continue with Google
      </button>

      <button
        onClick={() => handleProviderLogin('github')}
        className="w-full bg-black hover:bg-gray-800 text-white py-2 rounded flex items-center justify-center gap-2"
      >
        <img src="/icons/github.svg" alt="GitHub" className="w-5 h-5 invert" />
        Continue with GitHub
      </button>
    </div>
  );
}
