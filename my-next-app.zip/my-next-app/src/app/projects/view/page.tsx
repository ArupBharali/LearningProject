// src/app/projects/page.tsx

import { auth } from '@/lib/auth/auth';
import { redirect } from 'next/navigation';
import { listUserProjects } from '@/features/projects/api/project/listProjects';
import Link from 'next/link';
import ProjectFormByIdPage from '@/features/projects/components/ProjectFormByIdPage';

type PageProps = {
searchParams: {
  id: string;
  projectId: string;
  readOnly: boolean
}
}

export default async function ProjectViewEditPage({searchParams} : PageProps) {
  const session = await auth();
  if (!session) redirect('/login');

  const {id,projectId,readOnly}=await searchParams;
  
  return (
    <ProjectFormByIdPage searchParams={{ id, projectId, readonly: readOnly }}/>
  )

}
